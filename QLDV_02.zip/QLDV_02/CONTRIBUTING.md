# Nguyên tắc quản lý kho code QLĐV và Cách đóng góp
## Tài khoản quản lý
(https://github.com/DHCN1A-Group3)
* Kho code chính của QLĐV (QLĐV Repository) được quản lý thông qua tài khoản của tổ chức G3 Team - TCU.
* Tài khoản của tổ chức G3 Team - TCU được quản lý bởi đội ngũ phát triển code chính.
## Địa chỉ kho
(https://github.com/DHCN1A-Group3/4305_QLDoanVien)
## Nguyên tắc phát triển code
* Tự do đóng góp: Tất cả mọi người dù là người quản lý kho code, thành viên đội code hay những người đóng góp thuộc các tổ chức, công ty, các cá nhân… đều có thể đóng góp phát triển code một cách tự do.
* Ghi công đóng góp: Việc phát triển code phải thực hiện trên kho code riêng, không được code trực tiếp trên kho code chính của QLĐV (kể cả tài khoản của người quản lý kho code).
* Kiểm duyệt chéo: Những người quản lý kho code sẽ chịu trách nhiệm việc kiểm duyệt code được đóng góp vào kho code chính. (Nên hạn chế việc tự duyệt code của mình trên kho code chính).
## Quy trình tham gia phát triển code
* Để tham gia phát triển code, chỉ cần 1 tài khoản trên Github. Sau đó truy cập kho code của dự án, ấn nút Fork để copy project có sẵn thành project của mình, rồi sau đó ta có thể tự do chỉnh sửa project đó của mình.
* Chỉnh sửa xong thì ấn nút Pull Request để gửi yêu cầu đóng góp lên cho những người quản lý kho code.
* Những người quản lý kho code sẽ kiểm tra và phê duyệt các đóng góp này. Nếu đóng góp chưa đạt hoặc cần chỉnh sửa thì những người quản lý có thể viết góp ý ngay tại yêu cầu đóng góp và trả lại để người đóng góp chỉnh sửa theo góp ý và gửi lại sau khi đã sửa xong. Quá trình này diễn ra cho đến khi yêu cầu đóng góp được chấp nhận, đóng góp đó sẽ được trộn (merge) vào các nhánh phù hợp với dự án được đóng góp.
* Để tăng hiệu suất quản lý, toàn bộ công việc chỉnh sửa, xử lý xung đột… trước khi gửi đóng góp lên sẽ do người đóng góp xử lý. Người quản lý kho code sẽ chỉ việc kiểm tra và trả lời chứ không phải mất công để sửa lại code được đóng góp.
### Các chú ý
Trong quá trình làm phải commit thường xuyên lên nhánh của mình, khi xong xuôi thì merge/rebase vào nhánh master. Không nên chờ đến khi có kết quả cuối cùng mới commit lên kho code chính, vì như thế sẽ gia tăng nguy cơ xung đột code giữa các thành viên trong nhóm và giữa các nhóm với nhau.
## Cấu trúc tổ chức kho code
* Cấu trúc tổ chức kho code của QLĐV được phân nhành theo từng thành viên trong Team.
* Các thành viên sau khi commit và push lên nhánh của mình, sẽ merge vào master.
* Nhánh chính là nhánh Master, nhánh này luôn đảm bảo rằng code được lưu trữ trên đó là phiên bản chính thức mới nhất đang được phát hành.
* Để đánh dấu các mốc quan trọng (ví dụ các phiên bản được phát hành), ta sử dụng các tag. Các tag này sẽ giúp truy cập nhanh đến kho code tại thời điểm diễn ra dấu mốc sự kiện được đánh dấu.
