<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Doanphi Controller
 */
class Doanphi extends CI_Controller {
	/**
	 * Khởi tạo
	 */
	public function __construct() {
		parent::__construct();
		$this->load->model('Model_Doanvien');
		$this->load->model('Model_Doancs');
		$this->load->model('Model_Chidoan');
		$this->load->model('Model_Doanphi');
	}
	/**
	 * trang chính quản lý đoàn phí
	 * @return [type] [view home]
	 */
	public function index() {
		$mdCD = $this->Model_Chidoan;
		$listCD = $mdCD->get();
		$mdDCS = $this->Model_Doancs;
		$listDCS = $mdDCS->get();
		$mdDV = $this->Model_Doanvien;
		$listDV = $mdDV->get();
		$mdDP = $this->Model_Doanphi;

		$data = [
			'metaTitle' => 'Đoàn phí',
			'mainContent' => 'doanphi/home',
			'sb_page' => 'doanphi',
			'listCD' => $listCD,
			'listDCS' => $listDCS,
			'listDV' => $listDV
		];	

		$this->load->view('mainLayout', $data);
	}
	/**
	 * ajax xử lý lấy đoàn phí theo chi đoàn
	 * @return [type] [bảng đoàn phí]
	 */
	public function xulyGetDoanPhiChiDoan() {
		$maCD = $this->input->post('MACD');
		$mdDP = $this->Model_Doanphi;

		$listDP = $mdDP->getByCD($maCD);

		$data = [
			'listDP' => $listDP
		];

		$html = $this->load->view('doanphi/tblDoanPhi', $data, TRUE);

		echo json_encode($html);
		die;
	}
	/**
	 * ajax xử lý cập nhật đoàn phí
	 * @return [type] [kết quả cập nhật đoàn phí]
	 */
	public function xulyCapNhatDoanPhi() {
		$mdDP = $this->Model_Doanphi;
		$data['MADV'] = $this->input->post('MADV');
		$doanphi = $this->input->post('DOANPHI');

		$data['HK1'] = $data['HK2'] = $data['HK3'] = $data['HK4'] = $data['HK5'] = $data['HK6'] = $data['HK7'] = $data['HK8'] = 0;
		if ($doanphi != null) {
			foreach ($doanphi as $hk) {
				$data['HK' . $hk] = 1;
			}
		}
		
		if ($mdDP->update($data)) {
			$result = ['status' => true, 'message' => 'Successful!'];
		} else {
			$result = ['status' => false, 'message' => 'Error!'];
		}

		echo json_encode($result);
		die;
	}
}