<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Taikhoan Controller
 */
class Taikhoan extends CI_Controller {
	/**
	 * khởi tạo
	 */
	public function __construct() {
		parent::__construct();
		$this->load->model('Model_Taikhoan');
	}
	/**
	 * trang chính quản lý tài khoản
	 * @return [type] [view home]
	 */
	public function index() {
		if ($this->session->userdata('QUYEN') < 2) {
			@header("Location: " . base_url());
			@die;
		}
		$mdTK = $this->Model_Taikhoan;
		$listTK = $mdTK->get();

		$data = [
			'metaTitle' => 'Tài khoản',
			'mainContent' => 'taikhoan/home',
			'sb_page' => 'taikhoan',
			'listTK' => $listTK
		];	

		$this->load->view('mainLayout', $data);
	}
	/**
	 * trang đăng nhập
	 * @return [type] [view đăng nhập]
	 */
	public function dangnhap() {
		$this->load->view('taikhoan/dangnhap');
	}
	/**
	 * trang sửa/cập nhật thông tin tài khoản
	 * @param  string $tdn [tên đăng nhập]
	 * @return [type]      [view sửa]
	 */
	public function sua($tdn = "") {
		if ($this->session->userdata('QUYEN') < 2) {
			@header("Location: " . base_url());
			@die;
		}
		if (!empty($tdn)) {
			$mdTK = $this->Model_Taikhoan;
			$taikhoan = $mdTK->get($tdn);
			if ($taikhoan == null) {
				@header("Location: " . base_url('taikhoan'));
				@die;
			}
			
			$data = [
				'metaTitle' => 'Sửa thông tin | Tài khoản',
				'mainContent' => 'taikhoan/sua',
				'sb_page' => 'taikhoan',
				'taikhoan' => $taikhoan
			];	

			$this->load->view('mainLayout', $data);
		} else {
			@header("Location: " . base_url('taikhoan'));
			@die;
		}
	}
	/**
	 * trang xóa tài khoản
	 * @param  string $tdn [tên đăng nhập]
	 * @return [type]      [view xóa]
	 */
	public function xoa($tdn = "") {
		if ($this->session->userdata('QUYEN') < 2) {
			@header("Location: " . base_url());
			@die;
		}
		if (!empty($tdn)) {
			$mdTK = $this->Model_Taikhoan;
			$taikhoan = $mdTK->get($tdn);
			if ($taikhoan == null) {
				@header("Location: " . base_url('taikhoan'));
				@die;
			}
			
			$data = [
				'metaTitle' => 'Xóa | Tài khoản',
				'mainContent' => 'taikhoan/xoa',
				'sb_page' => 'taikhoan',
				'taikhoan' => $taikhoan
			];	

			$this->load->view('mainLayout', $data);
		} else {
			@header("Location: " . base_url('taikhoan'));
			@die;
		}
	}
	/**
	 * trang đổi mật khẩu
	 * @return [type] [view đổi mật khẩu]
	 */
	public function doimatkhau() {
		$data = [
			'metaTitle' => 'Đổi mật khẩu',
			'mainContent' => 'taikhoan/doimatkhau',
			'sb_page' => 'doimatkhau'
		];	

		$this->load->view('mainLayout', $data);
	}

	// Xử lý ajax
	/**
	 * ajax xử lý thêm tài khoản
	 * @return [type] [kết quả thêm tài khoản]
	 */
	public function xulyThemTK() {
		$params = $this->input->post();
		$mdTK = $this->Model_Taikhoan;

		if (!isset($params['TENDANGNHAP']) || empty($params['TENDANGNHAP'])) {
			$result = array(
				'status' => false,
				'message' => 'Chưa nhập tên đăng nhập'
			);
		} elseif (!isset($params['MATKHAU']) || empty($params['MATKHAU'])) {
			$result = array(
				'status' => false,
				'message' => 'Chưa nhập mật khẩu'
			);
		} elseif (!isset($params['NHAPLAIMATKHAU']) || empty($params['NHAPLAIMATKHAU'])) {
			$result = array(
				'status' => false,
				'message' => 'Chưa nhập lại mật khẩu'
			);
		} elseif (isset($params['NHAPLAIMATKHAU']) && isset($params['MATKHAU']) && $params['MATKHAU'] != $params['NHAPLAIMATKHAU']) {
			$result = array(
				'status' => false,
				'message' => 'Hai mật khẩu không khớp'
			);
		} else {
			if ($mdTK->get($params['TENDANGNHAP'])) {
				$result = array(
					'status' => false,
					'message' => 'Tên đăng nhập này đã được dùng. Hãy chọn tên đăng nhập khác'
				);
			} else {
				$data = [
					'TENDANGNHAP' => $params['TENDANGNHAP'],
					'MATKHAU' => $params['MATKHAU'],
					'QUYEN' => $params['QUYEN'],
					'TRANGTHAI' => $params['TRANGTHAI']
				];

				if ($mdTK->insert($data)) {
					$result = array(
						'status' => true,
						'message' => 'Thêm tài khoản thành công'
					);
				} else {
					$result = array(
						'status' => false,
						'message' => 'Lỗi khi thêm tài khoản'
					);
				}
			}
		}

		echo json_encode($result);
	}
	/**
	 * ajax xử lý sửa/ cập nhật tài khoản
	 * @return [type] [kết quả cập nhật tài khoản]
	 */
	public function xulySuaTK() {
		if ($this->session->userdata('QUYEN') < 2) {
			@header("Location: " . base_url());
			@die;
		}
		$params = $this->input->post();
		$mdTK = $this->Model_Taikhoan;

		if (!isset($params['TENDANGNHAP']) || empty($params['TENDANGNHAP'])) {
			$result = array(
				'status' => false,
				'message' => 'Chưa nhập tên đăng nhập'
			);
		} elseif (isset($params['NHAPLAIMATKHAU']) && isset($params['MATKHAU']) && !empty($params['MATKHAU']) && empty($params['NHAPLAIMATKHAU'])) {
			$result = array(
				'status' => false,
				'message' => 'Chưa nhập lại mật khẩu'
			);
		} elseif (isset($params['NHAPLAIMATKHAU']) && isset($params['MATKHAU']) && $params['MATKHAU'] != $params['NHAPLAIMATKHAU']) {
			$result = array(
				'status' => false,
				'message' => 'Hai mật khẩu không khớp'
			);
		} else {
			if (!$mdTK->get($params['TENDANGNHAP'])) {
				$result = array(
					'status' => false,
					'message' => 'Tên đăng nhập này không tồn tại. Vui lòng thử lại sau.'
				);
			} else {
				$data = [
					'TENDANGNHAP' => $params['TENDANGNHAP'],
					'MATKHAU' => $params['MATKHAU'],
					'QUYEN' => $params['QUYEN'],
					'TRANGTHAI' => $params['TRANGTHAI']
				];

				if ($mdTK->update($data)) {
					$result = array(
						'status' => true,
						'message' => 'Cập nhật thông tin thành công'
					);
				} else {
					$result = array(
						'status' => false,
						'message' => 'Lỗi khi cập nhật thông tin'
					);
				}
			}
		}

		echo json_encode($result);
	}
	/**
	 * ajax xử lý xóa tài khoản
	 * @return [type] [kết quả xóa tài khoản]
	 */
	function xulyXoaTK() {
		if ($this->session->userdata('QUYEN') < 2) {
			@header("Location: " . base_url());
			@die;
		}
		$mdTK = $this->Model_Taikhoan;
		$tdn = $this->input->post('TENDANGNHAP');
		
		if (!$mdTK->existed($tdn)) {
			$result = array(
				'status' => false,
				'message' => 'Tên đăng nhập này không tồn tại. Vui lòng kiểm tra lại.'
			);
		} else {
			if ($mdTK->delete($tdn)) {
				$result = array(
					'status' => true,
					'message' => 'Xóa tài khoản thành công'
				);
			} else {
				$result = array(
					'status' => false,
					'message' => 'Lỗi khi xóa tài khoản'
				);
			}
		}

		echo json_encode($result);
		die;
	}
	/**
	 * ajax xử lý đăng nhập
	 * @return [type] [kết quả đăng nhập]
	 */
	public function xulyDangNhap() {
		$mdTK = $this->Model_Taikhoan;
		$params = $this->input->post();

		if (empty($params['TENDANGNHAP'])) {
			$result = ['status' => false, 'message' => 'Chưa nhập tên đăng nhập.'];
		} elseif (empty($params['MATKHAU'])) {
			$result = ['status' => false, 'message' => 'Chưa nhập mật khẩu.'];
		} else {
			if ($mdTK->existed($params['TENDANGNHAP'])) {
				$nv = $mdTK->get($params['TENDANGNHAP']);
				if (!password_verify($params['MATKHAU'], $nv['MATKHAU'])) {
					$result = ['status' => false, 'message' => 'Mật khẩu không đúng.'];
				} else {
					// Tạo session
					$this->session->set_userdata('TENDANGNHAP', $nv['TENDANGNHAP']);
					$this->session->set_userdata('QUYEN', $nv['QUYEN']);

					$result = ['status' => true, 'message' => 'Đăng nhập thành công.'];
				}
			} else {
				$result = ['status' => false, 'message' => 'Tên đăng nhập không tồn tại. Vui lòng kiểm tra lại.'];
			}
		}

		echo json_encode($result);
		die;
	}
	/**
	 * xử lý thoát
	 * @return [type] [thoát khỏi hệ thống]
	 */
	public function thoat() {
		$this->session->unset_userdata('TENDANGNHAP');
		$this->session->unset_userdata('QUYEN');
		@header("Location: " . base_url('taikhoan/dangnhap'));
		@die;
	}
	/**
	 * ajax xử lý đổi mật khẩu
	 * @return [type] [kết quả đổi mật khẩu]
	 */
	public function xulyDoiMK() {
		$mdTK = $this->Model_Taikhoan;
		$params = $this->input->post();

		if (empty($params['MKCu'])) {
			$result = ['status' => false, 'message' => 'Chưa nhập mật khẩu cũ.'];
		} elseif (empty($params['MKMoi'])) {
			$result = ['status' => false, 'message' => 'Chưa nhập mật khẩu mới.'];
		} elseif (empty($params['reMKMoi'])) {
			$result = ['status' => false, 'message' => 'Chưa nhập lại mật khẩu mới.'];
		} elseif ($params['MKMoi'] != $params['reMKMoi']) {
			$result = ['status' => false, 'message' => 'Hai mật khẩu mới không khớp.'];
		} else {
			$tk = $mdTK->get($this->session->userdata('TENDANGNHAP'));
			if (!password_verify($params['MKCu'], $tk['MATKHAU'])) {
				$result = ['status' => false, 'message' => 'Mật khẩu cũ không đúng.'];
			} else {
				$data = [
					'TENDANGNHAP' => $this->session->userdata('TENDANGNHAP'),
					'MATKHAU' => $params['MKMoi'],
					'QUYEN' => $tk['QUYEN'],
					'TRANGTHAI' => $tk['TRANGTHAI']
				];

				if ($mdTK->update($data)) {
					$result = ['status' => true, 'message' => 'Đổi mật khẩu thành công.'];
				} else {
					$result = ['status' => false, 'message' => 'Đã có lỗi xảy ra.'];
				}
			}
		}

		echo json_encode($result);
		die;
	}
}
