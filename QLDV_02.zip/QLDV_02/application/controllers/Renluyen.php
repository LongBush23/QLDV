<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Renluyen Controller
 */
class Renluyen extends CI_Controller {
	/**
	 * khởi tạo
	 */
	public function __construct() {
		parent::__construct();
		$this->load->model('Model_Doanvien');
		$this->load->model('Model_Doancs');
		$this->load->model('Model_Chidoan');
		$this->load->model('Model_Renluyen');
	}
	/**
	 * trang chính quản lý rèn luyện
	 * @return [type] [view home]
	 */
	public function index() {
		$mdCD = $this->Model_Chidoan;
		$listCD = $mdCD->get();
		$mdDCS = $this->Model_Doancs;
		$listDCS = $mdDCS->get();

		$data = [
			'metaTitle' => 'Rèn luyện',
			'mainContent' => 'renluyen/home',
			'sb_page' => 'renluyen',
			'listCD' => $listCD,
			'listDCS' => $listDCS
		];	

		$this->load->view('mainLayout', $data);
	}
	/**
	 * ajax xử lý rèn luyện chi đoàn
	 * @return [type] [dữ liệu rèn luyện chi đoàn]
	 */
	public function xulyGetRenLuyenChiDoan() {
		$maCD = $this->input->post('MACD');
		$hocky = $this->input->post('HOCKY');
		$mdRL = $this->Model_Renluyen;

		$listRL = $mdRL->getByCD($maCD, $hocky);

		$data = [
			'listRL' => $listRL
		];

		$html = $this->load->view('renluyen/tblRenLuyen', $data, TRUE);

		echo json_encode($html);
		die;
	}
	/**
	 * ajax xử lý cập nhật rèn luyện
	 * @return [type] [kết quả cập nhật rèn luyện]
	 */
	public function xulyCapNhatRenLuyen() {
		$mdRL = $this->Model_Renluyen;
		$data = $this->input->post();

		if ($mdRL->update($data)) {
			$result = ['status' => true, 'message' => 'Successful!'];
		} else {
			$result = ['status' => false, 'message' => 'Error!'];
		}

		echo json_encode($result);
		die;
	}
}