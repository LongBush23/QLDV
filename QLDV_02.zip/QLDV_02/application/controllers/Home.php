<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Home Controller
 */
class Home extends CI_Controller {
	/**
	 * khởi tạo
	 */
	public function __construct() {
		parent::__construct();
		$this->load->model('Model_Doanvien');
		$this->load->model('Model_Doancs');
		$this->load->model('Model_Chidoan');
	}
	/**
	 * trang chính
	 * @return [type] [view home]
	 */
	public function index() {
		$mdDV = $this->Model_Doanvien;
		$mdDCS = $this->Model_Doancs;
		$mdCD = $this->Model_Chidoan;
		$numDVTotal = $mdDV->numTotal();
		$listDCS = $mdDCS->get();

		$numByDCS = [];
		foreach ($listDCS as $item) {
			$numByDCS[$item['MADCS']]['TENDCS'] = $item['TENDCS'];			
			$numByDCS[$item['MADCS']]['NUMCD'] = $mdCD->numByDCS($item['MADCS']);
			$numByDCS[$item['MADCS']]['NUMDV'] = $mdDV->numByDCS($item['MADCS']);
		}

		$data = [
			'metaTitle' => 'Trang chủ',
			'mainContent' => 'home/home',
			'sb_page' => 'home',
			'numDVTotal' => $numDVTotal,
			'numByDCS' => $numByDCS,
		];	

		$this->load->view('mainLayout', $data);
	}
}
