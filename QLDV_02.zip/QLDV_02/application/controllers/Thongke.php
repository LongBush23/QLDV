<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Thongke Controller
 */
class Thongke extends CI_Controller {
	/**
	 * khởi tạo
	 */
	public function __construct() {
		parent::__construct();
		$this->load->model('Model_Doanvien');
		$this->load->model('Model_Doancs');
		$this->load->model('Model_Chidoan');
		$this->load->model('Model_Renluyen');
		$this->load->model('Model_Doanphi');
	}
	/**
	 * trang chính thống kê
	 * @return [type] [view home thống kê]
	 */
	public function index() {
		$mdCD = $this->Model_Chidoan;
		$listCD = $mdCD->get();
		$mdDCS = $this->Model_Doancs;
		$listDCS = $mdDCS->get();
		$mdDV = $this->Model_Doanvien;
		$listDV = $mdDV->get();
		
		$data = [
			'metaTitle' => 'Thống kê',
			'mainContent' => 'thongke/home',
			'sb_page' => 'thongke',
			'listCD' => $listCD,
			'listDCS' => $listDCS,
			'listDV' => $listDV
		];	

		$this->load->view('mainLayout', $data);
	}
	/**
	 * ajax xử lý xem thống kê
	 * @return [type] [bảng thống kê]
	 */
	public function xulyXemThongKe() {
		$loai = $this->input->post('LOAI');
		$maCD = $this->input->post('MACD');
		$hocky = $this->input->post('HOCKY');
		$mdCD = $this->Model_Chidoan;

		$tenCD = $mdCD->get($maCD)['TENCD'];

		$html = "";
		if ($loai == 'DOANPHI') {
			$mdDP = $this->Model_Doanphi;
			$listDP = $mdDP->getByCDHK($maCD, $hocky);
			$data = [
				'listDP' => $listDP,
				'tenCD' => $tenCD,
				'hocky' => $hocky
			];
			$html = $this->load->view('thongke/tblDoanPhi', $data, TRUE);
			
		} elseif ($loai == 'RENLUYEN') {
			$mdRL = $this->Model_Renluyen;
			$listRL = $mdRL->getByCD($maCD, $hocky);
			$data = [
				'listRL' => $listRL,
				'tenCD' => $tenCD,
				'hocky' => $hocky
			];
			$html = $this->load->view('thongke/tblRenLuyen', $data, TRUE);
		}

		echo json_encode($html);
		die;
	}
}