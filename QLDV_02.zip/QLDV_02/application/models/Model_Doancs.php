<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Model_Doancs
 */
class Model_Doancs extends CI_Model {
	/**
	 * bảng doancs
	 * @var string
	 */
	private $myTable = 'doancs';
	/**
	 * khởi tạo
	 */
	function __construct() {
		parent::__construct();
	}
	/**
	 * kiểm tra tồn tại đoàn cơ sở
	 * @param  [type] $maDCS [mã đoàn cơ sở]
	 * @return [type]        [tồn tại trả về true; không tồn tại trả về false]
	 */
	public function existed($maDCS) {
		if ($this->db->where('MADCS', $maDCS)->from($this->myTable)->count_all_results() > 0) return true;
		return false;
	}
	/**
	 * lấy thông tin đoàn cơ sở
	 * @param  string $maDCS [mã đoàn cơ sở]
	 * @return [type]        [nếu $madcs rỗng thì trả về toàn bộ danh sách đoàn cơ sở; nếu $madcs có thì trả về thông tin đoàn cơ sở theo mã]
	 */
	public function get($maDCS = "") {
		if (!empty($maDCS)) {
			$dcs = $this->db->where('MADCS', $maDCS)->get($this->myTable)->result_array();
			if (count($dcs) > 0) return $dcs[0];
			return null;
		} else {
			return $this->db->get($this->myTable)->result_array();
		}
	}
	/**
	 * thêm mới đoàn cơ sở
	 * @param  array  $data [bảng dữ liệu cần thêm]
	 * @return [type]       [kết quả thêm]
	 */
	public function insert($data = []) {
		if ($data) {
			return $this->db->insert($this->myTable, $data);
		}
		return false;
	}
	/**
	 * cập nhật đoàn cơ sở
	 * @param  array  $data [bảng dữ liệu cần cập nhật]
	 * @return [type]       [kết quả cập nhật]
	 */
	public function update($data = []) {
		if ($data) {
			return $this->db->where('MADCS', $data['MADCS'])->update($this->myTable, $data);
		}
		return false;
	}
	/**
	 * xóa đoàn cơ sở
	 * @param  [type] $maDCS [mã đoàn cơ sở]
	 * @return [type]        [kết quả xóa]
	 */
	public function delete($maDCS) {
		if ($maDCS) {
			return $this->db->where('MADCS', $maDCS)->delete($this->myTable);
		}
		return false;
	}
}