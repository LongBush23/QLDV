<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Model_Chidoan
 */
class Model_Chidoan extends CI_Model {
	/**
	 * bảng chidoan
	 * @var string
	 */
	private $myTable = 'chidoan';
	/**
	 * khởi tạo
	 */
	function __construct() {
		parent::__construct();
	}
	/**
	 * kiểm tra tồn tại chi đoàn
	 * @param  [type] $maCD [mã chi đoàn]
	 * @return [type]       [chi đoàn tồn tại hay chưa]
	 */
	public function existed($maCD) {
		if ($this->db->where('MACD', $maCD)->from($this->myTable)->count_all_results() > 0) return true;
		return false;
	}
	/**
	 * đếm số lượng chi đoàn theo đoàn cơ sở
	 * @param  [type] $maDCS [mã đoàn cơ sở]
	 * @return [type]        [số lượng chi đoàn]
	 */
	public function numByDCS($maDCS) {
		return $this->db->where('MADCS', $maDCS)->get($this->myTable)->num_rows();
	}
	/**
	 * lấy danh sách chi đoàn theo đoàn cơ sở
	 * @param  [type] $maDCS [mã đoàn cơ sở]
	 * @return [type]        [danh sách chi đoàn]
	 */
	public function getByDCS($maDCS) {
		return $this->db->where('MADCS', $maDCS)->get($this->myTable)->result_array();
	}
	/**
	 * lấy danh sách chi đoàn
	 * @param  string $maCD [mã chi đoàn]
	 * @return [type]       [nếu mã CD rỗng thì trả về toàn bộ danh sách chi đoàn; còn nến có mã CD thì trả về thông tin chi đoàn theo mã]
	 */
	public function get($maCD = "") {
		if (!empty($maCD)) {
			$dcs = $this->db->where('MACD', $maCD)->get($this->myTable)->result_array();
			if (count($dcs) > 0) return $dcs[0];
			return null;
		} else {
			return $this->db->get($this->myTable)->result_array();
		}
	}
	/**
	 * thêm mới chi đoàn
	 * @param  array  $data [bảng dữ liệu cần thêm]
	 * @return [type]       [kết quả thêm]
	 */
	public function insert($data = []) {
		if ($data) {
			return $this->db->insert($this->myTable, $data);
		}
		return false;
	}
	/**
	 * cập nhật thông tin chi đoàn
	 * @param  array  $data [bảng dữ liệu cập nhật]
	 * @return [type]       [kết quả cập nhật]
	 */
	public function update($data = []) {
		if ($data) {
			return $this->db->where('MACD', $data['MACD'])->update($this->myTable, $data);
		}
		return false;
	}
	/**
	 * xóa chi đoàn
	 * @param  [type] $maCD [mã chi đoàn]
	 * @return [type]       [kết quả xóa]
	 */
	public function delete($maCD) {
		if ($maCD) {
			return $this->db->where('MACD', $maCD)->delete($this->myTable);
		}
		return false;
	}
}