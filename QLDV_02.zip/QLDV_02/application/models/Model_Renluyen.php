<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Model_Renluyen
 */
class Model_Renluyen extends CI_Model {
	/**
	 * khởi tạo
	 */
	function __construct() {
		parent::__construct();
	}
	/**
	 * lấy thông tin rèn luyện
	 * @param  string $maDV [mã đoàn viên]
	 * @return [type]       [thông tin đoàn viên]
	 */
	public function get($maDV = "") {
		if (!empty($maDV)) {

			$sql = "SELECT * FROM renluyen WHERE MADV='".$maDV."'";
			
			$dp = $this->db->query($sql)->result_array();
			if (count($dcs) > 0) return $dcs[0];
			return null;
		}
		return null;
	}
	/**
	 * lấy thông tin rèn luyện theo chi đoàn
	 * @param  string  $maCD  [mã chi đoàn]
	 * @param  integer $hocky [học kỳ]
	 * @return [type]         [bảng thông tin rèn luyện]
	 */
	public function getByCD($maCD = "", $hocky = 1) {
		if (!empty($maCD)) {

			$sql = "SELECT rl.*, dv.HODV, dv.TENDV FROM renluyen as rl INNER JOIN doanvien as dv ON rl.MADV = dv.MADV WHERE dv.MACD='".$maCD."' AND rl.HOCKY=".$hocky;
			
			return $this->db->query($sql)->result_array();
		}
		return null;
	}
	/**
	 * thêm thông tin rèn luyện
	 * @param  string $maDV [mã đoàn viên]
	 * @return [type]       [kết quả thêm]
	 */
	public function insert($maDV = "") {
		if ($maDV) {
			for ($i=1; $i<=8 ; $i++) { 

				$sql = "INSERT INTO renluyen (MADV,HOCKY,DIEM,XEPLOAI) VALUES ('".$maDV."',".$i.",0,'Chưa xếp loại')";
				$this->db->query($sql);
			}
			return true;
		}
		return false;
	}
	/**
	 * cập nhật thông tin rèn luyện
	 * @param  array  $data [bảng thông tin rèn luyện]
	 * @return [type]       [kết quả cập nhật]
	 */
	public function update($data = []) {
		if ($data) {

			$sql = "UPDATE renluyen SET DIEM=".$data['DIEM'].", XEPLOAI='".$data['XEPLOAI']."' WHERE MADV='".$data['MADV']."' AND HOCKY=".$data['HOCKY'];

			return $this->db->query($sql);
		}
		return false;
	}
	/**
	 * xóa thông tin rèn luyện
	 * @param  [type] $maDV [mã đoàn viên]
	 * @return [type]       [kết quả xóa]
	 */
	public function delete($maDV) {
		if ($maDV) {
			$sql = "DELETE FROM renluyen WHERE MADV='".$maDV."'";
			return $this->db->query($sql);
		}
		return false;
	}
}