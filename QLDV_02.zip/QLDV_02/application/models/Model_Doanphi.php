<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Model_Doanphi
 */
class Model_Doanphi extends CI_Model {
	/**
	 * khởi tạo
	 */
	function __construct() {
		parent::__construct();
	}
	/**
	 * lấy thông tin đoàn phí theo đoàn viên
	 * @param  string $maDV [mã đoàn viên]
	 * @return [type]       [bảng đoàn phí]
	 */
	public function get($maDV = "") {
		if (!empty($maDV)) {

			$sql = "SELECT * FROM doanphi WHERE MADV='".$maDV."'";
			
			$dp = $this->db->query($sql)->result_array();
			if (count($dcs) > 0) return $dcs[0];
			return null;
		}
		return null;
	}
	/**
	 * lấy thông tin đoàn phí thep chi đoàn
	 * @param  string $maCD [mã chi đoàn]
	 * @return [type]       [bảng đoàn phí]
	 */
	public function getByCD($maCD = "") {
		if (!empty($maCD)) {

			$sql = "SELECT dp.*, dv.HODV, dv.TENDV FROM doanphi as dp INNER JOIN doanvien as dv ON dp.MADV = dv.MADV WHERE dv.MACD='".$maCD."'";
			
			return $this->db->query($sql)->result_array();
		}
		return null;
	}
	/**
	 * lấy thông tin đoàn phí chi đoàn theo học kỳ
	 * @param  string  $maCD  [mã chi đoàn]
	 * @param  integer $hocky [học kỳ]
	 * @return [type]         [bảng đoàn phí]
	 */
	public function getByCDHK($maCD = "", $hocky = 1) {
		if (!empty($maCD)) {

			$sql = "SELECT dp.MADV, dp.HK".$hocky." as DOANPHI, dv.HODV, dv.TENDV FROM doanphi as dp INNER JOIN doanvien as dv ON dp.MADV = dv.MADV WHERE dv.MACD='".$maCD."'";
			
			return $this->db->query($sql)->result_array();
		}
		return null;
	}
	/**
	 * thêm bảng đoàn phí
	 * @param  string $maDV [mã đoàn viên]
	 * @return [type]       [kết quả thêm]
	 */
	public function insert($maDV = "") {
		if ($maDV) {

			$sql = "INSERT INTO doanphi (MADV) VALUES ('".$maDV."')";
			
			return $this->db->query($sql);
		}
		return false;
	}
	/**
	 * cập nhật thông tin đoàn phí
	 * @param  array  $data [bảng thông tin đoàn phí]
	 * @return [type]       [kết quả cập nhật]
	 */
	public function update($data = []) {
		if ($data) {

			$sql = "UPDATE doanphi SET HK1=".$data['HK1'].",HK2=".$data['HK2'].",HK3=".$data['HK3'].",HK4=".$data['HK4'].",HK5=".$data['HK5'].",HK6=".$data['HK6'].",HK7=".$data['HK7'].",HK8=".$data['HK8']." WHERE MADV='".$data['MADV']."'";

			return $this->db->query($sql);
		}
		return false;
	}
	/**
	 * xóa bảng đoàn phí
	 * @param  [type] $maDV [mã đoàn phí]
	 * @return [type]       [kêt quả xóa]
	 */
	public function delete($maDV) {
		if ($maDV) {
			
			$sql = "DELETE FROM doanphi WHERE MADV='".$maDV."'";

			return $this->db->query($sql);
		}
		return false;
	}
}