<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Model_Taikhoan
 */
class Model_Taikhoan extends CI_Model {
	/**
	 * bảng taikhoan
	 * @var string
	 */
	private $myTable = 'taikhoan';
	/**
	 * khởi tạo
	 */
	function __construct() {
		parent::__construct();
	}
	/**
	 * kiểm tra tồn tại tài khoản
	 * @param  [type] $tnd [tên đăng nhập]
	 * @return [type]      [nếu tồn tại trả về true; không thì trả về false]
	 */
	public function existed($tnd) {
		if ($this->db->where('TENDANGNHAP', $tnd)->from($this->myTable)->count_all_results() > 0) return true;
		return false;
	}
	/**
	 * lấy thông tin tài khoản
	 * @param  string $tnd [tên đăng nhập]
	 * @return [type]      [thông tin tài khoản]
	 */
	public function get($tnd = "") {
		if (!empty($tnd)) {
			$nv = $this->db->where('TENDANGNHAP', $tnd)->get($this->myTable)->result_array();
			if (count($nv) > 0) return $nv[0];
			return null;
		} else {
			return $this->db->get($this->myTable)->result_array();
		}
	}
	/**
	 * thêm tài khoản
	 * @param  array  $data [dữ liệu cần thêm]
	 * @return [type]       [kết quả thêm]
	 */
	public function insert($data = []) {
		if ($data) {
			$data['MATKHAU'] = password_hash($data['MATKHAU'], PASSWORD_DEFAULT);
			return $this->db->insert($this->myTable, $data);
		}
		return false;
	}
	/**
	 * cập nhật thông tin tài khoản
	 * @param  array  $data [dữ liệu cần cập nhật]
	 * @return [type]       [kết quả cập nhật]
	 */
	public function update($data = []) {
		if ($data) {
			if (empty($data['MATKHAU'])) {
				unset($data['MATKHAU']);
			} else {
				$data['MATKHAU'] = password_hash($data['MATKHAU'], PASSWORD_DEFAULT);
			}
			return $this->db->where('TENDANGNHAP', $data['TENDANGNHAP'])->update($this->myTable, $data);
		}
		return false;
	}
	/**
	 * xóa tài khoản
	 * @param  [type] $tnd [tên đăng nhập]
	 * @return [type]      [kết quả xóa]
	 */
	public function delete($tnd) {
		if ($tnd) {
			return $this->db->where('TENDANGNHAP', $tnd)->delete($this->myTable);
		}
		return false;
	}
}