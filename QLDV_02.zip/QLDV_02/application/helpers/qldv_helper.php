<?php
defined('BASEPATH') OR exit('No direct script access allowed');

include __DIR__ . '/../third_party/PHPExcel/PHPExcel/IOFactory.php';

if ( ! function_exists('day_encode'))
{
    function day_encode($str = "") {
    	if (!empty($str)) {
    		return DateTime::createFromFormat('d/m/Y', $str)->format('Y-m-d');
    	}
    	return "";
    }
}

if ( ! function_exists('day_decode'))
{
    function day_decode($str = "") {
    	if (!empty($str)) {
    		return DateTime::createFromFormat('Y-m-d', $str)->format('d/m/Y');
    	}
    	return "";
    }
}

if ( ! function_exists('readExcel'))
{
    function readExcel($inputFileName = "") {
        if (!empty($inputFileName)) {
            try {
                $inputFileType = PHPExcel_IOFactory::identify($inputFileName);
                $objReader = PHPExcel_IOFactory::createReader($inputFileType);
                $objPHPExcel = $objReader->load($inputFileName);
            } catch(Exception $e) {
                die('Lỗi không thể đọc file "'.pathinfo($inputFileName,PATHINFO_BASENAME).'": '.$e->getMessage());
            }
            $sheet = $objPHPExcel->getSheet(0); 
 
            // Lấy tổng số dòng của file, trong trường hợp này là 6 dòng
            $highestRow = $sheet->getHighestRow(); 
             
            // Lấy tổng số cột của file, trong trường hợp này là 4 dòng
            $highestColumn = $sheet->getHighestColumn();
             
            // Khai báo mảng $rowData chứa dữ liệu
            $data = [];
            //  Thực hiện việc lặp qua từng dòng của file, để lấy thông tin
            for ($row = 1; $row <= $highestRow; $row++){ 
                // Lấy dữ liệu từng dòng và đưa vào mảng $rowData
                $data[] = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, NULL, TRUE, FALSE);
            }
            
            unset($data[0]);
            return $data;
        }
        return null;
    }
}