<div id="content-DoanVien">
	<section class="content">
		<div class="box box-success">
			<div class="box-header with-border">
				<h3 class="box-title"><?php echo $taikhoan['TENDANGNHAP']; ?> <small> - Sửa thông tin</small></h3>
			</div>
			<!-- Main content -->
			<div class="box-body">
				<div class="row">
					<div class="col-md-6 col-xs-12">
						<form id="frmSuaTK" enctype="multipart/form-data">
							<div class="form-group">
								<label>Tên đăng nhập</label>
								<input type="text" class="form-control" name="TENDANGNHAP" placeholder="Nhập tên đăng nhập" value="<?php echo $taikhoan['TENDANGNHAP']; ?>" readonly>
							</div>
							<div class="form-group">
								<label>Mật khẩu</label>
								<input type="password" class="form-control" name="MATKHAU" placeholder="Nhập mật khẩu">
							</div>
							<div class="form-group">
								<label>Nhập lại mật khẩu</label>
								<input type="password" class="form-control" name="NHAPLAIMATKHAU" placeholder="Nhập lại mật khẩu">
							</div>
							<div class="form-group">
								<label>Phân quyền</label>
								<select name="QUYEN" class="form-control select2" style="width: 100%;">
									<option value="0" <?php echo (($taikhoan['QUYEN'] == 0) ? 'selected' : ''); ?>>Quản lý chi đoàn</option>
									<option value="1" <?php echo (($taikhoan['QUYEN'] == 1) ? 'selected' : ''); ?>>Quản lý đoàn cơ sở</option>
									<option value="2" <?php echo (($taikhoan['QUYEN'] == 2) ? 'selected' : ''); ?>>Quản lý hệ thống</option>
								</select>
							</div>
							<div class="form-group">
								<label>Trạng thái</label>
								<div class="radio-group">
									<label>
										<input type="radio" name="TRANGTHAI" class="minimal-blue icheck" value="1" <?php echo (($taikhoan['TRANGTHAI'] == 1) ? 'checked' : ''); ?>>
										<span class="text-success">Hoạt động</span>
									</label>
									<label style="padding-left: 40px;">
										<input type="radio" name="TRANGTHAI" class="minimal-blue icheck" value="0" <?php echo (($taikhoan['TRANGTHAI'] == 0) ? 'checked' : ''); ?>>
										<span class="text-danger">Tạm khóa</span>
									</label>
								</div>
							</div>
						</form>
					</div>
				</div>	
				<div class="row" style="margin: 0px;">
					<div id="errSuaTK" style="display: none;margin-bottom: 10px;"></div>
					<div id="ajaxLoadingBar" style="display: none;margin-bottom: 10px;"></div>
				</div>
				<div class="row" style="margin: 0px;">
					<button type="button" class="btn btn-warning btn-flat" onclick="App.TaiKhoan.SuaTK();return false;">Cập nhật</button>
					<a href="<?php echo base_url('taikhoan'); ?>" class="btn btn-default btn-flat">Hủy</a>
				</div>
			</div>
		</div>
	</section>
</div>