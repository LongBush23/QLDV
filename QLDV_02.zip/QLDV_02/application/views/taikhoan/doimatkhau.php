<section class="content">
	<div class="box box-success">
		<div class="box-header with-border">
			<h3 class="box-title">Đổi mật khẩu</h3>
		</div>
		<!-- Main content -->
		<div class="box-body">
			<div class="row">
				<div class="col-xs-6">
					<form id="frmDoiMK" enctype="multipart/form-data">
						<div class="form-group">
							<label>Mật khẩu cũ</label>
							<input type="password" class="form-control" name="MKCu" placeholder="Nhập mật khẩu cũ">
						</div>
						<div class="form-group">
							<label>Mật khẩu mới</label>
							<input type="password" class="form-control" name="MKMoi" placeholder="Nhập mật khẩu mới">
						</div>
						<div class="form-group">
							<label>Nhập lại mật khẩu mới</label>
							<input type="password" class="form-control" name="reMKMoi" placeholder="Nhập lại mật khẩu mới">
						</div>
						<div class="row" style="margin: 0px;">
							<div id="errDoiMK" style="display: none;margin-bottom: 10px;"></div>
							<div id="ajaxLoadingBar" style="display: none;margin-bottom: 10px;"></div>
						</div>
						<div class="form-group">
							<button onclick="App.TaiKhoan.DoiMK();return false;" class="btn btn-info btn-flat">Đổi mật khẩu</button>
							<a href="<?php echo base_url(); ?>" class="btn btn-default btn-flat">Hủy bỏ</a>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</section>