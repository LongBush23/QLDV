<div class="col-xs-12">
	<div class="nav-tabs-custom">
		<ul class="nav nav-tabs">
			<li class="active"><a href="#tab_1" data-toggle="tab"><strong>TẤT CẢ</strong></a></li>
			<li><a href="#tab_2" data-toggle="tab"><strong class="text-success">XUẤT SẮC</strong></a></li>
			<li><a href="#tab_3" data-toggle="tab"><strong class="text-warning">KHÁ</strong></a></li>
			<li><a href="#tab_4" data-toggle="tab"><strong class="text-info">TRUNG BÌNH</strong></a></li>
			<li><a href="#tab_5" data-toggle="tab"><strong class="text-danger">YẾU</strong></a></li>
			<li><a href="#tab_6" data-toggle="tab"><strong>CHƯA XẾP LOẠI</strong></a></li>
			<li class="pull-right"><button id="btnPrint" onclick="App.Site.printThongKe('#tblThongKe .tab-pane.active'); return false;" type="button" class="btn btn-success btn-flat"><strong><i class="fa fa-print"></i> IN</strong></button></li>
		</ul>
		<div class="tab-content bg-info">
			<div class="tab-pane active" id="tab_1">
				<div class="row">
					<div class="col-xs-12">
						<h3>DANH SÁCH RÈN LUYỆN LỚP <?php echo $tenCD; ?> (HỌC KỲ <?php echo $hocky; ?>)</h3>
					</div>
				</div>
				<div class="row" style="margin-top: 15px;">
					<div class="col-xs-12">
						<div class="table-responsive">
							<table class="table table-bordered table-hover">
								<tr class="bg-green">
									<th class="text-center">STT</th>
									<th class="text-center">Mã đoàn viên</th>
									<th class="text-center">Họ tên đoàn viên</th>
									<th class="text-center">Điểm rèn luyện</th>
									<th class="text-center">Xếp loại</th>
								</tr>
							<?php foreach ($listRL as $i => $dv): ?>
								<tr>
									<td class="text-center"><?php echo $i+1; ?></td>
									<td class="text-center"><?php echo $dv['MADV']; ?></td>
									<td class="text-center"><?php echo $dv['HODV']; ?> <?php echo $dv['TENDV']; ?></td>
									<td class="text-center"><?php echo $dv['DIEM']; ?></td>
									<td class="text-center"><?php echo $dv['XEPLOAI']; ?></td>
								</tr>
							<?php endforeach ?>
							</table>
						</div>
					</div>
				</div>
			</div>

			<div class="tab-pane" id="tab_2">
				<div class="row">
					<div class="col-xs-12">
						<h3>DANH SÁCH ĐOÀN VIÊN XUẤT SẮC LỚP <?php echo $tenCD; ?> (HỌC KỲ <?php echo $hocky; ?>)</h3>
					</div>
				</div>
				<div class="row" style="margin-top: 15px;">
					<div class="col-xs-12">
						<div class="table-responsive">
							<table class="table table-bordered table-hover">
								<tr class="bg-green">
									<th class="text-center">STT</th>
									<th class="text-center">Mã đoàn viên</th>
									<th class="text-center">Họ tên đoàn viên</th>
									<th class="text-center">Điểm rèn luyện</th>
									<th class="text-center">Xếp loại</th>
								</tr>
							<?php $i = 1;
							foreach ($listRL as $dv): ?>
							<?php if ($dv['XEPLOAI'] == 'Xuất sắc'): ?>
								<tr>
									<td class="text-center"><?php echo $i; $i++; ?></td>
									<td class="text-center"><?php echo $dv['MADV']; ?></td>
									<td class="text-center"><?php echo $dv['HODV']; ?> <?php echo $dv['TENDV']; ?></td>
									<td class="text-center"><?php echo $dv['DIEM']; ?></td>
									<td class="text-center"><?php echo $dv['XEPLOAI']; ?></td>
								</tr>
							<?php endif ?>
							<?php endforeach ?>
							</table>
						</div>
					</div>
				</div>
			</div>

			<div class="tab-pane" id="tab_3">
				<div class="row">
					<div class="col-xs-12">
						<h3>DANH SÁCH ĐOÀN VIÊN KHÁ LỚP <?php echo $tenCD; ?> (HỌC KỲ <?php echo $hocky; ?>)</h3>
					</div>
				</div>
				<div class="row" style="margin-top: 15px;">
					<div class="col-xs-12">
						<div class="table-responsive">
							<table class="table table-bordered table-hover">
								<tr class="bg-green">
									<th class="text-center">STT</th>
									<th class="text-center">Mã đoàn viên</th>
									<th class="text-center">Họ tên đoàn viên</th>
									<th class="text-center">Điểm rèn luyện</th>
									<th class="text-center">Xếp loại</th>
								</tr>
							<?php $i = 1;
							foreach ($listRL as $dv): ?>
							<?php if ($dv['XEPLOAI'] == 'Khá'): ?>
								<tr>
									<td class="text-center"><?php echo $i; $i++; ?></td>
									<td class="text-center"><?php echo $dv['MADV']; ?></td>
									<td class="text-center"><?php echo $dv['HODV']; ?> <?php echo $dv['TENDV']; ?></td>
									<td class="text-center"><?php echo $dv['DIEM']; ?></td>
									<td class="text-center"><?php echo $dv['XEPLOAI']; ?></td>
								</tr>
							<?php endif ?>
							<?php endforeach ?>
							</table>
						</div>
					</div>
				</div>
			</div>

			<div class="tab-pane" id="tab_4">
				<div class="row">
					<div class="col-xs-12">
						<h3>DANH SÁCH ĐOÀN VIÊN TRUNG BÌNH LỚP <?php echo $tenCD; ?> (HỌC KỲ <?php echo $hocky; ?>)</h3>
					</div>
				</div>
				<div class="row" style="margin-top: 15px;">
					<div class="col-xs-12">
						<div class="table-responsive">
							<table class="table table-bordered table-hover">
								<tr class="bg-green">
									<th class="text-center">STT</th>
									<th class="text-center">Mã đoàn viên</th>
									<th class="text-center">Họ tên đoàn viên</th>
									<th class="text-center">Điểm rèn luyện</th>
									<th class="text-center">Xếp loại</th>
								</tr>
							<?php $i = 1;
							foreach ($listRL as $dv): ?>
							<?php if ($dv['XEPLOAI'] == 'Trung bình'): ?>
								<tr>
									<td class="text-center"><?php echo $i; $i++; ?></td>
									<td class="text-center"><?php echo $dv['MADV']; ?></td>
									<td class="text-center"><?php echo $dv['HODV']; ?> <?php echo $dv['TENDV']; ?></td>
									<td class="text-center"><?php echo $dv['DIEM']; ?></td>
									<td class="text-center"><?php echo $dv['XEPLOAI']; ?></td>
								</tr>
							<?php endif ?>
							<?php endforeach ?>
							</table>
						</div>
					</div>
				</div>
			</div>

			<div class="tab-pane" id="tab_5">
				<div class="row">
					<div class="col-xs-12">
						<h3>DANH SÁCH ĐOÀN VIÊN YẾU LỚP <?php echo $tenCD; ?> (HỌC KỲ <?php echo $hocky; ?>)</h3>
					</div>
				</div>
				<div class="row" style="margin-top: 15px;">
					<div class="col-xs-12">
						<div class="table-responsive">
							<table class="table table-bordered table-hover">
								<tr class="bg-green">
									<th class="text-center">STT</th>
									<th class="text-center">Mã đoàn viên</th>
									<th class="text-center">Họ tên đoàn viên</th>
									<th class="text-center">Điểm rèn luyện</th>
									<th class="text-center">Xếp loại</th>
								</tr>
							<?php $i = 1;
							foreach ($listRL as $dv): ?>
							<?php if ($dv['XEPLOAI'] == 'Yếu'): ?>
								<tr>
									<td class="text-center"><?php echo $i; $i++; ?></td>
									<td class="text-center"><?php echo $dv['MADV']; ?></td>
									<td class="text-center"><?php echo $dv['HODV']; ?> <?php echo $dv['TENDV']; ?></td>
									<td class="text-center"><?php echo $dv['DIEM']; ?></td>
									<td class="text-center"><?php echo $dv['XEPLOAI']; ?></td>
								</tr>
							<?php endif ?>
							<?php endforeach ?>
							</table>
						</div>
					</div>
				</div>
			</div>

			<div class="tab-pane" id="tab_6">
				<div class="row">
					<div class="col-xs-12">
						<h3>DANH SÁCH ĐOÀN VIÊN CHƯA XẾP LOẠI LỚP <?php echo $tenCD; ?> (HỌC KỲ <?php echo $hocky; ?>)</h3>
					</div>
				</div>
				<div class="row" style="margin-top: 15px;">
					<div class="col-xs-12">
						<div class="table-responsive">
							<table class="table table-bordered table-hover">
								<tr class="bg-green">
									<th class="text-center">STT</th>
									<th class="text-center">Mã đoàn viên</th>
									<th class="text-center">Họ tên đoàn viên</th>
									<th class="text-center">Điểm rèn luyện</th>
									<th class="text-center">Xếp loại</th>
								</tr>
							<?php $i = 1;
							foreach ($listRL as $dv): ?>
							<?php if ($dv['XEPLOAI'] == 'Chưa xếp loại'): ?>
								<tr>
									<td class="text-center"><?php echo $i; $i++; ?></td>
									<td class="text-center"><?php echo $dv['MADV']; ?></td>
									<td class="text-center"><?php echo $dv['HODV']; ?> <?php echo $dv['TENDV']; ?></td>
									<td class="text-center"><?php echo $dv['DIEM']; ?></td>
									<td class="text-center"><?php echo $dv['XEPLOAI']; ?></td>
								</tr>
							<?php endif ?>
							<?php endforeach ?>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>