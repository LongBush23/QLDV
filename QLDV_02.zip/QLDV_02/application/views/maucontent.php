<section class="content">
	<div class="box box-success">
		<div class="box-header with-border">
			<h3 class="box-title">Tiêu đề</h3>
		</div>
		<div class="box-body">
			Nội dung đang cập nhật!
		</div>
	</div>
</section>