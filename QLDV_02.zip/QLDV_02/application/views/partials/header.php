<header class="main-header">
	<a title="Trang chủ" href="" class="logo">
		<span class="logo-mini"><img src="https://upload.wikimedia.org/wikipedia/vi/4/46/Logo_HCMUNRE.png" alt="Logo Đoàn" height="40px"></span>
		<span class="logo-lg"><img src="https://upload.wikimedia.org/wikipedia/vi/4/46/Logo_HCMUNRE.png" alt="Logo Đoàn" height="40px"> -  QLĐV</span>
	</a>

	<nav class="navbar navbar-static-top">
		<a data-placement="bottom" title="Thu gọn / Mở rộng MENU" href="javascipt:;" class="sidebar-toggle" data-toggle="offcanvas" role="button" onclick="App.Site.changeSidebar();return false;">
			<span class="sr-only">Toggle navigation</span>
		</a>

		<div class="navbar-custom-menu">
        	<ul class="nav navbar-nav">
				
        	</ul>
      	</div>
    </nav>
</header>