<!-- <footer class="main-footer">
	<div class="pull-right hidden-xs">
		<b>Phiên bản</b> 0.0.1 (beta)
	</div>

	<strong><a href="<?php echo base_url(); ?>">KARAOKE LIMA</a>.</strong> Xây dựng bởi <a target="_blank" href="http://quocdatit.com"><strong>Quốc Đạt IT</strong></a>.
</footer> -->